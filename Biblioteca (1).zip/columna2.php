 <div class="col-sm-6">
<?
if($campo==""){
$sql="SELECT cons,nombre,isbn,autor,codigo,paginas,genero,editorial,lanzamiento,caratula 
       FROM tbllibros";
}else{
  $campo=trim($campo);
  $sql="SELECT cons,nombre,isbn,autor,codigo,paginas,
genero,editorial,lanzamiento,caratula FROM tbllibros where nombre like '$campo%'";
}
//incluir conexion
include 'confing/conexion.php';
$registro=mysqli_query($con,$sql)or die ('Error en sql'.$sql);
echo '<table><tr><td>ISBN</td><td>Nombre</td><td><td/></tr>';
while($r=mysqli_fetch_array($registro)){
  echo "<tr><td>".$r['codigo']."</td><td>".$r['nombre']."</td>
<td><img src=img/".$r['caratula']."></td></tr>";
}

?>
 </table>
    </div>