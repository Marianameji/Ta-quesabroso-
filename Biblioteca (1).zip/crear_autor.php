<?
$fecha=$_POST['fecha'];
$nombre=$_POST['nombre'];
include 'confing/conexion.php';
if(empty($nombre) || empty($fecha))
{
echo '<br>Los campos Marcados con (*) son obligatorios';
} else{
//include 'config/conexion.php';
if(!$con){
 die("Error en la conexión");
 }
$sql ="INSERT INTO tblautor(nombre,fecha_nacimiento)values('$nombre','$telefono')";
echo '<br>'.$sql;
$consulta = mysqli_query($con,$sql)
or die("Fallo en la inserción".mysqli_error($con));
mysqli_close($con);
}

?>
<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>
<?include 'presentacion.php'?>

<div class="container">
  <h2> Autores || <a href="index.php">
    Regresar</a> </h2>
  <div class="row">
  <div class="col">
  <form action="#" method="POST">
   <input type="text" 
          name="nombre" 
          maxlength="30"
          class="form control"
          placeholder="nombre del autor"
          title="Name autor, your length max of field is 30">
    <label for="fecha">birth date</label>
    <input type="date" name="fecha">
    <button type=="submit" class btn btn-info>Save</button>
  </form>
    
  </div>  
   <div class="col">
     Listado de autores
     <?
     $sql="SELECT Nombres, Nacionalidad, Fecha_nacimiento, fecha_muerte, Cons FROM Autores";
     $registro=mysqli_query($con,$sql) or die('Error en sql'.$sql);
  echo '<table><tr><td>nombre</td><td>fecha-nacimiento</td><td>nacionalidad</td><td>cons</td></tr>';
  while($r=mysqli_fetch_array($registro)){
    echo "<tr><td>" .$r['Nombres']. "</td><td>" .$r['Fecha_nacimiento'].  "</td><td>".$r['Fecha_muerte'].  "</td><td>" .$r['Nacionalidad'].  "</td><td>" .$r['Cons'].  "</td>
     </tr>";
  }
  mysqli_close($con);
    ?>
  </div>  
  </div>

</div>
</body>
</html>
