<?
$host="b8efz9rovnnaumfxfv6y-mysql.services.clever-cloud.com";
$bd="b8efz9rovnnaumfxfv6y";
$user="ujlf6btmsfnqtock";
$pwd="myA5U4p7RiZq7o7mhNcv";
$con=mysqli_connect($host,$user,$pwd,$bd) or
  die(" Problemas en la conexion");

?>