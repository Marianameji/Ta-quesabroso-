<div class="jumbotron text-center">
  <h1>My pet angel</h1>
  <p>
  <img src="img/mypet.png"> 

</p>
</div>
