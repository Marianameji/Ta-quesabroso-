<head>
  <html>
<head>
 <title>mas</title>cotas
 <link rel="stylesheet" href="css/menu.css">
<link rel="stylesheet" herl="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
 <meta http-eqiv="X-UA-Compatible" content="IE-edge">
 <meta name="viewport" content="widht-device-widht, initial-scale=1.0">
<link rel="stylesheet" href="../estilo/estilo3.css">
</head>
<body>
<h2>Menú</h2>
<nav>
<ul>
 <li><a href="index.php">Volver</a></li>
 <li><a href="formulario.php">Registra</a></li>
<li><a href="contacto.php">Contacto</a></li>
  <li><a href="acerca de.php">Acerca de</a></li>
</ul>
</nav>
</body>
</html>

  <title>Comida Saludable</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>