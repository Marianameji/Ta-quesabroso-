<div class="col-sm-4">
      <h3>Búsqueda de informacion </h3>
     <div>
       <form class="form-group" 
             action="index.php"
             method="post">
         <input type="text" 
           name="campo" 
           clas="form-group"
           placeholder="Ingrese un criterio de búsqueda" title="ingrese las primeras letras de la mascota a buscar">
         <button type="submit" 
           class="btn btn-success form-group">Buscar</button>
       </form>
     </div>
    </div>