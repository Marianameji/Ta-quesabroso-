<div class="col-sm-6">
     <?
$sql="";
$campo=$_POST['campo'];
  if($campo==""){
   // $sql="SELECT mascotas,registros,veterinarios,tiendas,img
     //FROM informacion";
  }else{
    $sql="SELECT id, nombre, ubicacion, direccion,telefono,img  from Tiendas where nombre like '$campo%'";
  

include 'config/conexion.php';
  $registro=mysqli_query($con,$sql) or die('Error en sql');
  echo '<table border=1><tr><td>id</td><td>nombre</td></td><td>ubicacion</td></td><td>direccion</td></td>telefono<td></td></tr>';
  while($r=mysqli_fetch_array($registro)){
    echo "<tr><td>".$r['id']."</td>
   <td>".$r['nombre']."</td><td>".$r['ubicacion']."</td><td>".$r['direccion']."</td><td>".$r['telefono']."</td><td><img src=img/".$r['img']."></td>
</tr>";
   
    
  }
  }
?>
</table>
  </div>