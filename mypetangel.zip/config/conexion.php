<?
$host="b8dlgev9jjlkinrwecpr-mysql.services.clever-cloud.com";
$bd="b8dlgev9jjlkinrwecpr";
$user="uxiur8y5vqwldnb0";
$pwd="AzgYNzPFIR2G4IciKoAm";
$con=mysqli_connect($host,$user,$pwd,$bd) or
    die(" Problemas en la conexión");
?>