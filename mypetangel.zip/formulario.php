<html>
  <head><title>formulario</title></head>
  <link rel="stylesheet" href="ejercicio2.css">
  <body>
     <h1><i>Formulario de registro</i></h1>
     <form action="" method="get">
     <fieldset>
     <legend>Datos personales</legend>
        <p>
          Nombre: <input type="text" name="nombre" maxlength="30">
        </p>
        <p>
          Apellidos: <input type="text" name="apellidos" maxlength="30">
        <p/>
        <p>
          Sexo: <input type="radio" name="sexo" value="h">Hombre
          Sexo: <input type="radio" name="sexo" value="m">Mujer
        </p>
        <p>
          Correo: <input type="text" name="correo" maxlength="50">
        </p>
       </fieldset>
        <fieldset>
        <legend>Autorización</legend>
        <p>
          <input type="checkbox" name="info" checked="checked">Deseo
          recibir información sobre novedades y ofertas.
        </p>
        <p>
          <input type="checkbox" name="condiciones" checked="checked">Declarohaber leido
          y aceptar las condiciones generales del programa y la normativa
          sobre programación web.
        </p>
        </fieldset>
        <fieldset>
        <legend>Botones</legend>
        <p> 
          <input type="submit" value="Enviar">
          <button type="reset">Limpiar</button> 
        </p>
        <p>
          <button formaction="index.php">Volver</button>
        </p>
       </fieldset>
     </from>
  </body>
</html>